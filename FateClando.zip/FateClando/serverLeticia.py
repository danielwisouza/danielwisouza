import socket
import threading
import rsa
from datetime import datetime

# Endereço do servidor e cliente (Bruna)
HOST = ''
SERVER = '127.0.0.1'

# Portas em que o servidor vai executar
PORT_ORIGIN = 5002
PORT_DEST = 5001

# Socket tcp
tcp_listen = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcp_send = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Caminhos das chaves publica (Bruna) e privada (Letícia)
pub_key_file = '.\BrunaPub.txt'     #certo
pri_key_file = '.\LeticiaPri.txt'

# Origem e destino das mensagem recebidas
origin = (HOST, PORT_ORIGIN)
destination = (SERVER, PORT_DEST)

def listen():
    ## Passa a escutar o outro server
    tcp_listen.bind(origin) # liga a um IP e porta específicos para que possa ouvir as solicitações
    tcp_listen.listen(1)    # método que o coloca em modo de escuta
    while True:
        connection, client = tcp_listen.accept() #estabele conexão(ler)
        while True:
            ## Recebe a mensagem enviada pela outra pessoa
            encrypted_message = connection.recv(1024) #igual professor
            if not encrypted_message:
                break
            
            ## Desencripta usando a chave privada e imprime a mensagem
            file = open(pri_key_file, 'rb')
            file_content = file.read()
            file.close()
            pri_key = rsa.PrivateKey.load_pkcs1(file_content, format='PEM')
            message = rsa.decrypt(encrypted_message, pri_key)

            print('\n%s Bruna: %s\n' % (datetime.now().strftime('%H:%M'), message.decode('utf-8')))
            
        print('Conversa encerrada.')
        connection.close()

def send():
    ## Estabelece uma conexão com o outro server
    tcp_send.connect(destination)
    print('Conexão estabelecida')

    print ('Para sair use CTRL+X\n')
    message = input()
    while message != '\x18':
        ## Encripta a mensagem usando a chave pública
        file = open(pub_key_file, 'rb')
        file_content = file.read()
        file.close()
        pub_key = rsa.PublicKey.load_pkcs1(file_content, format='PEM')
        encrypted_message = rsa.encrypt(message.encode('utf-8'), pub_key)

        ## Envia a mensagem ao outro servidor
        tcp_send.send(encrypted_message)
        message = input()
    print('Conversa encerrada.')
    tcp_send.close()

## Inicia as threads de listen e send
threading.Thread(target=listen).start()
threading.Thread(target=send).start()
